package ffos.p3.ontologija_simenic;


import java.io.Serializable;

public class Ontologija implements Serializable {

    public Ontologija() {
        this.sifra = sifra;
        this.ime_redatelja = ime_redatelja;
        this.grad_premijere = grad_premijere;
        this.uDrzavi = uDrzavi;
        this.jePremijernoPrikazan = jePremijernoPrikazan;
        this.uGodini = uGodini;
        this.zaradioJe = zaradioJe;
    }

    private int sifra;
    private String ime_redatelja;
    private String grad_premijere;
    private String uDrzavi;
    private String jePremijernoPrikazan;
    private String uGodini;
    private int zaradioJe;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public String getIme_redatelja() {
        return ime_redatelja;
    }

    public void setIme_redatelja(String ime_redatelja) {
        this.ime_redatelja = ime_redatelja;
    }

    public String getGrad_premijere() {
        return grad_premijere;
    }

    public void setGrad_premijere(String grad_premijere) {
        this.grad_premijere = grad_premijere;
    }

    public String getuDrzavi() {
        return uDrzavi;
    }

    public void setuDrzavi(String uDrzavi) {
        this.uDrzavi = uDrzavi;
    }

    public String getJePremijernoPrikazan() {
        return jePremijernoPrikazan;
    }

    public void setJePremijernoPrikazan(String jePremijernoPrikazan) {
        this.jePremijernoPrikazan = jePremijernoPrikazan;
    }

    public String getuGodini() {
        return uGodini;
    }

    public void setuGodini(String uGodini) {
        this.uGodini = uGodini;
    }

    public int getZaradioJe() {
        return zaradioJe;
    }

    public void setZaradioJe(int zaradioJe) {
        this.zaradioJe = zaradioJe;
    }
}